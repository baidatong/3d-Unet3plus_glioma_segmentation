clear all;
[filename pathname]= uigetfile('*.gz');

v_t = niftiread([ filename]);
info_original = niftiinfo(filename);
temp = info_original.PixelDimensions;

v_t_2 = v_t(:,end:-1:1,:);

niftiwrite(v_t_2, ['trainning_' filename(1:end-7)],'Compressed' ,true);

info2 = niftiinfo( ['trainning_' filename(1:end-7) '.nii.gz']);
info2 = niftiinfo( ['trainning_' filename(1:end-7) '.nii.gz']);
info2.PixelDimensions = [1 1 temp(3)];
info2.raw.pixdim = [1,1,1,temp(3),0,0,0,0];
niftiwrite(v_t_2, [filename],info2,'Compressed' ,true);
